import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class HostelBookingsScreen extends StatefulWidget {
  String hostelId = "-O3f_uujiR0hkusE2V3T";

  HostelBookingsScreen({super.key, required this.hostelId});

  @override
  _HostelBookingsScreenState createState() => _HostelBookingsScreenState();
}

class _HostelBookingsScreenState extends State<HostelBookingsScreen> {
  final DatabaseReference databaseRef =
      FirebaseDatabase.instance.ref("bookings");

  // Function to delete a specific booking
  void _deleteBooking(String bookingId) async {
    try {
      await databaseRef.child(bookingId).remove();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking deleted successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete booking: $e')),
      );
    }
  }

  void deleteBookingByDetails(String userUid, String hostelName,
      String roomNumber, String cnicNumber) async {
    DatabaseReference databaseReference = FirebaseDatabase.instance.ref();

    // Query to find the booking based on userUid
    databaseReference
        .child("room_bookings")
        .orderByChild("user_ID")
        .equalTo(userUid)
        .once()
        .then((DatabaseEvent event) {
      DataSnapshot snapshot = event.snapshot;
      if (snapshot.value != null) {
        Map<dynamic, dynamic> bookings =
            snapshot.value as Map<dynamic, dynamic>;

        bookings.forEach((key, value) {
          // Check if hostel_name, room_ID, and cnic_number match
          if (value['hostel_name'] == hostelName &&
              value['room_ID'] == roomNumber &&
              value['cnic_number'] == cnicNumber) {
            // Match found, delete the booking
            databaseReference
                .child("room_bookings")
                .child(key)
                .remove()
                .then((_) {
              print("Booking deleted successfully.");
            }).catchError((error) {
              print("Failed to delete booking: $error");
            });
          }
        });
      } else {
        print("No booking found for the given details.");
      }
    }).catchError((error) {
      print("Error retrieving bookings: $error");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookings'),
      ),
      body: StreamBuilder(
        stream: databaseRef
            .orderByChild('hostel_name')
            .equalTo(widget.hostelId)
            .onValue, // Replaces Future with stream for real-time updates
        builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.snapshot.value == null) {
              return const Center(child: Text('No bookings found'));
            }

            Map<dynamic, dynamic> bookingsMap =
                snapshot.data!.snapshot.value as Map<dynamic, dynamic>;

            List<MapEntry<dynamic, dynamic>> bookingsList =
                bookingsMap.entries.toList();

            return ListView.builder(
              itemCount: bookingsList.length,
              itemBuilder: (context, index) {
                var bookingEntry = bookingsList[index];
                var booking = bookingEntry.value;

                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    child: ListTile(
                      title: Text("Hostel Name: ${booking['hostel_name']}"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                              "Name: ${booking['First name']}  ${booking['Last name']}"),
                          Text("Booking Type: ${booking['booking_type']}"),
                          Text("CNIC: ${booking['cnic_number']}"),
                          Text("Roll Number: ${booking['room_number']}"),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          // Call the delete function when delete icon is tapped
                          _deleteBooking(bookingEntry.key);
                          //
                          print("Hostel Name ${booking['hostel_name']}");
                          print("User ID ${booking['user_uid']}");
                          print("room_ID ${booking['room_number']}");
                          deleteBookingByDetails(
                              booking['user_uid'],
                              booking['hostel_name'],
                              booking['room_number'],
                              booking['cnic_number']);
                        },
                      ),
                    ),
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
